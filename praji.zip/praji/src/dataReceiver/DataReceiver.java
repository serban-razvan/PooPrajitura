package dataReceiver;

import inputs.GameSummary;

public interface DataReceiver {
	public GameSummary receive();
}
