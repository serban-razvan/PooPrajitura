package inputs;

public interface StatInput {

}
