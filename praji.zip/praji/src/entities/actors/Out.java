package entities.actors;

public class Out implements Actor {

}
