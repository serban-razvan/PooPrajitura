package entities.actors;

public interface Actor {
	
}
