package entities.actors;

public class Fault implements Actor {

}
