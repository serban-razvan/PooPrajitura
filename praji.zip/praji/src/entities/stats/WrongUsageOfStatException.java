package entities.stats;

public class WrongUsageOfStatException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
